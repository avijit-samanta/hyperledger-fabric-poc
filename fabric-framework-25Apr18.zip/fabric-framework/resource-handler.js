
var fs = require('fs');
var moment = require('moment');
var reportFile ='./Report/ExecutionReport.xlsx';
var logFile ='./Report/Executionlog.txt';
var sheet='Result';

var updateLog = function(message){
    var now = moment();
    var formatted = now.format('YYYY-MM-DD HH:mm:ss');
    fs.appendFile(logFile,"["+formatted+"]"+message+"\n",function(err){
      if(err){
        console.error(err);
      }
    console.log(message);
    });    
}
var resetReport = function(){
    updateLog('Clearing the report file...');
  clearReportColumn(reportFile, sheet, 'Info', '');
  clearReportColumn(reportFile, sheet, 'Status', '-');
  clearReportColumn(reportFile, sheet, 'Data', '-');
}

var clearReportColumn = function(reportFile, sheet, header, data){
    if(typeof require !== 'undefined') {
        XLSX = require('xlsx');
    }
    var workbook = XLSX.readFile(reportFile);
    var sheets = workbook.SheetNames;
    var sheetData = [];
    var worksheet;
    sheets.forEach(function(name) {
        if(name == sheet){
            worksheet = workbook.Sheets[name];
        }
    });

    var selCol;
    for(cell in worksheet) {
        if(cell[0] === '!') continue;
        var token = 0;
        for (var i = 0; i < cell.length; i++) {
            if (!isNaN(cell[i])) {
                token = i;
                break;
            }
        };
        var col = cell.substring(0,token);
        var row = parseInt(cell.substring(token));
        var value = worksheet[cell].v;

        if(row == 1 && worksheet[cell].v==header) {
            selCol=col;
        }
    }

    for(cell in worksheet) {
        if(cell[0] === '!') continue;
        var token = 0;
        for (var i = 0; i < cell.length; i++) {
            if (!isNaN(cell[i])) {
                token = i;
                break;
            }
        };
        var col = cell.substring(0,token);
        var row = parseInt(cell.substring(token));
        if(row!=1 && col==selCol){
            worksheet[cell].v=data;   
        }
    }

    XLSX.writeFile(workbook, reportFile);
    return sheetData;
}

var updateStatus = function(identifier, status){
       if(status){
        updateReport(identifier, 'Status', 'Pass');     
       }else{
        updateReport(identifier, 'Status', 'Fail');     
       }
}

var updateReport = function(identifier, header, data){
    if(typeof require !== 'undefined') {
        XLSX = require('xlsx');
    }
    var workbook = XLSX.readFile(reportFile);
    var sheets = workbook.SheetNames;
    var sheetData = [];
    var worksheet;
    sheets.forEach(function(name) {
        if(name == sheet){
            worksheet = workbook.Sheets[name];
         }
    });


    var selRow,selCol;
    for(cell in worksheet) {
        if(cell[0] === '!') continue;
        var token = 0;
        for (var i = 0; i < cell.length; i++) {
            if (!isNaN(cell[i])) {
                token = i;
                break;
            }
        };
        var col = cell.substring(0,token);
        var row = parseInt(cell.substring(token));
        var value = worksheet[cell].v;

         if(worksheet[cell].v==identifier){
            selRow=row;
         }

        if(row == 1 && worksheet[cell].v==header) {
            selCol=col;
        }
    }

    for(cell in worksheet) {
        if(cell[0] === '!') continue;
        var token = 0;
        for (var i = 0; i < cell.length; i++) {
            if (!isNaN(cell[i])) {
                token = i;
                break;
            }
        };
        var col = cell.substring(0,token);
        var row = parseInt(cell.substring(token));
        if(row==selRow && col==selCol){
            updateLog(sheet + '-'+header+', cell['+row+','+col+'] changing from "'+worksheet[cell].v +'" to "' + data +'"');  
            worksheet[cell].v=data;   
        }
    }

    XLSX.writeFile(workbook, reportFile);
    return sheetData;
}


var loadExecutionManager = function(reportFile, sheet){

    if(typeof require !== 'undefined') {
        XLSX = require('xlsx');
    }
    var workbook = XLSX.readFile(reportFile);
    var sheets = workbook.SheetNames;
    var sheetData = [];
    
    sheets.forEach(function(name) {
    if(name == sheet){
    updateLog("Loading data from "+reportFile+", sheet:"+sheet+"...");
    var worksheet = workbook.Sheets[name];
    var headers = {};
    var data = [];
    for(cell in worksheet) {
        if(cell[0] === '!') continue;
        //parse out the column, row, and value
        var token = 0;
        for (var i = 0; i < cell.length; i++) {
            if (!isNaN(cell[i])) {
                token = i;
                break;
            }
        };
        var col = cell.substring(0,token);
        var row = parseInt(cell.substring(token));
        var value = worksheet[cell].v;

        //store header names
        if(row == 1 && value) {
            headers[col] = value;
            continue;
        }

        if(!data[row]) data[row]={};
        data[row][headers[col]] = value; // <- Store with HeaderName
        //data[row][col] = value;   // <- Store with HeaderIndex
    }
    
        sheetData = data;
     }
});
return sheetData;
}

var fetchColumnData = function(rowData, columnName){
    var value = "-";

     if(typeof rowData!=='undefined'){
         Object.keys(rowData).forEach(function(key) {
         if(key==columnName){
             value=String(rowData[key]);
         }
      });
    }
    return value;
}

exports.loadExecutionManager = loadExecutionManager;
exports.fetchColumnData = fetchColumnData;
exports.updateReport = updateReport;
exports.updateStatus = updateStatus;
exports.resetReport = resetReport;
exports.updateLog = updateLog;

