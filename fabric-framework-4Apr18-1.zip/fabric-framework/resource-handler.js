

var loadExecutionManager = function(filePath){

if(typeof require !== 'undefined') {
    XLSX = require('xlsx');
}
var workbook = XLSX.readFile(filePath);
var sheets = workbook.SheetNames;
var sheetData = [];
sheets.forEach(function(name) {
    var worksheet = workbook.Sheets[name];
    var headers = {};
    var data = [];
    //console.log('Reading sheet "' + name +'"...');
    for(cell in worksheet) {
        if(cell[0] === '!') continue;
        //parse out the column, row, and value
        var token = 0;
        for (var i = 0; i < cell.length; i++) {
            if (!isNaN(cell[i])) {
                token = i;
                break;
            }
        };
        var col = cell.substring(0,token);
        var row = parseInt(cell.substring(token));
        var value = worksheet[cell].v;

        //store header names
        if(row == 1 && value) {
            headers[col] = value;
            continue;
        }

        if(!data[row]) data[row]={};
        data[row][headers[col]] = value; // <- Store with HeaderName
        //data[row][col] = value;   // <- Store with HeaderIndex
    }
    if(name == 'Execution'){
        sheetData = data;
     }
});
return sheetData;
}

var fetchColumnData = function(rowData, columnName){
var value = "-";

 if(typeof rowData!=='undefined'){
  Object.keys(rowData).forEach(function(key) {
   if(key==columnName){
    value=String(rowData[key]);
   }
  });
 }
 return value;
}

exports.loadExecutionManager = loadExecutionManager;
exports.fetchColumnData = fetchColumnData;

