'use strict';
var resource= require('./resource-handler');

require('./config.js');
var hfc = require('fabric-client');
var helper = require('./app/helper.js');
var channels = require('./app/create-channel.js');
var join = require('./app/join-channel.js');
var install = require('./app/install-chaincode.js');
var instantiate = require('./app/instantiate-chaincode.js');
var invoke = require('./app/invoke-transaction.js');
var query = require('./app/query.js');

////////////////////////////////////////////////////////////////////////////////////

var testData = resource.loadExecutionManager('./ExecutionManager.xlsx');

//console.log(helper.getRegisteredUsers(username, orgname, true));

for(var i=0;i<testData.length;i++){
  if(resource.fetchColumnData(testData[i],'Enabled')=='Yes'){
    switch(resource.fetchColumnData(testData[i],'Function')){
     case 'ValidateChannelInfo':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var channel = resource.fetchColumnData(testData[i],'Channel');

      query.getChannels(peer, username, orgname).then(function(response) {
	var channels = [];
        var result=false;
	for (let i = 0; i < response.channels.length; i++) {
           if(response.channels[i].channel_id==channel){
              result=true;
              break;
           }
	}
	console.log('ValidateChannelInfo:'+result);        
      });
      break;

     case 'ValidateInstalledChaincodes':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var code = resource.fetchColumnData(testData[i],'Chaincode');
      var version = resource.fetchColumnData(testData[i],'ChainVersion');
      var path = resource.fetchColumnData(testData[i],'ChainPath');
      query.getInstalledChaincodes(peer, 'installed', username, orgname).then(function (chaincodes) {
      var result=false;
       chaincodes.forEach(function(chaincode){
         if(chaincode.toString()=='name: '+code+', version: '+version+', path: '+path){result=true;}
       });
       console.log('ValidateInstalledChaincodes:'+result); 
      });
      break;

     case 'ValidateChainLength':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var oldChainLenght = resource.fetchColumnData(testData[i],'ChainLength');
                        
      query.getChainInfo(peer, username, orgname).then((blockchainInfo) => {
		if (blockchainInfo) {
                        var blockShift = Number.parseInt(blockchainInfo.height) - Number.parseInt(oldChainLenght);

                        if(blockShift>0){
                                console.log('Current block chain lenght:'+blockchainInfo.height + ', shifted by '+ blockShift);
                       }                     
		}});
      break;
     case 'ValidateBlockHash':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var offset = resource.fetchColumnData(testData[i],'HashOffset');
      query.getChainInfo(peer, username, orgname).then((blockchainInfo) => {
		if (blockchainInfo) {
			console.log("currentBlockHash:"+blockchainInfo.currentBlockHash);
                        console.log("previousBlockHash:"+blockchainInfo.previousBlockHash);
                        if (blockchainInfo.currentBlockHash.offset == offset){
                                console.log('Current block offset:'+blockchainInfo.currentBlockHash.offset + ', validation: OK');
                       }                  
                   
		}});
      break;
     case 'InvokeChaincode':
      var peers = resource.fetchColumnData(testData[i],'Peer').split(', ');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var channelName = resource.fetchColumnData(testData[i],'Channel');
      var chaincodeName = resource.fetchColumnData(testData[i],'Chaincode');

      invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peers[0], channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peers[1], channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID(peers[0], trxnId, username, orgname);
        query.getTransactionByID(peers[1], trxnId, username, orgname).then((block) => {
                        console.log(block);
			console.log("block:"+blockc.header);
		});;

        query.getBlockByNumber(peer, blockId, username, orgname);        
      });
      break;
    }
  }
}

/*
query.getChannels(peer, username, orgname);
query.getBlockByNumber(peer, '1', username, orgname);
query.getInstalledChaincodes(peer, 'installed', username, orgname);
query.getChainInfo(peer, username, orgname)

invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peer, channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peer, channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID('peer1', trxnId, 'Avijit', 'org1');
        query.getTransactionByID('peer2', trxnId, 'Barry', 'org1');

        query.getBlockByNumber(peer, blockId, username, orgname);        
});

*/

