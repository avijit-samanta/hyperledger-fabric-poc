var networkLibrary = require('./enrollment');
var queryLibrary= require('./query');

//networkLibrary.enrollAdmin('http://localhost:7054', 'ca.example.com', 'admin', 'adminpw', 'Org1MSP');
//networkLibrary.registerUser('http://localhost:7054','org1.department1', 'admin', 'user1', 'Org1MSP');

queryLibrary.query('queryCar','CAR5');
queryLibrary.query('queryAllCars','-');
