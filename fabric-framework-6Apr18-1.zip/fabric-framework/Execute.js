'use strict';
var resource= require('./resource-handler');

require('./config.js');
const delay = require('delay');
var hfc = require('fabric-client');
var helper = require('./app/helper.js');
var channels = require('./app/create-channel.js');
var join = require('./app/join-channel.js');
var install = require('./app/install-chaincode.js');
var instantiate = require('./app/instantiate-chaincode.js');
var invoke = require('./app/invoke-transaction.js');
var query = require('./app/query.js');
var sleep = require('system-sleep');
var typeOf = require('get-type-of');

////////////////////////////////////////////////////////////////////////////////////

var testData = resource.loadExecutionManager('./ExecutionManager.xlsx', 'Execution');
resource.resetReport();

for(var i=0;i<testData.length;i++){
  if(resource.fetchColumnData(testData[i],'Enabled')=='Yes'){
    var identifier = resource.fetchColumnData(testData[i],'Identifier');
    var scenario = resource.fetchColumnData(testData[i],'Function');
    var peer = resource.fetchColumnData(testData[i],'Peer');
    var username = resource.fetchColumnData(testData[i],'User');
    var orgname = resource.fetchColumnData(testData[i],'Organization');
    var channel = resource.fetchColumnData(testData[i],'Channel');
    var chainName = resource.fetchColumnData(testData[i],'Chaincode');
    var chainVersion = resource.fetchColumnData(testData[i],'ChainVersion');
    var chainPath = resource.fetchColumnData(testData[i],'ChainPath');
    var chainFunction = resource.fetchColumnData(testData[i],'ChainFunction');
    var chainParams= resource.fetchColumnData(testData[i],'ChainParams');
    var oldChainLenght = resource.fetchColumnData(testData[i],'ChainLength');
    var blockNumber = resource.fetchColumnData(testData[i],'BlockNumber');
    var transactionID = resource.fetchColumnData(testData[i],'TransactionID');
    var expectedMessage = resource.fetchColumnData(testData[i],'ExpectedMessage');
    var peers = resource.fetchColumnData(testData[i],'Peer').split(', ');
    var params = chainParams.split(', ');
              
    resource.updateLog('Executing scenario'+'-'+identifier+':'+scenario+"...");sleep(2000);
    switch(scenario){
     case 'ValidateChannelInfo':
      query.getChannels(peer, username, orgname).then(function(response) {
	var channels = [];
        var result=false;
	for (let i = 0; i < response.channels.length; i++) {
           if(response.channels[i].channel_id==channel){
              resource.updateReport(identifier, 'Data', response.channels[i].channel_id);  
              result=true;
              break;
           }
	}
        resource.updateStatus(identifier, result);            
      });
      break;

     case 'ValidateTransactionByBlock':
      query.getBlockByNumber(peer, blockNumber, username, orgname).then(function (response) {
        var result=false;
        if(transactionID==response.data.data[0].payload.header.channel_header.tx_id)result=true;
        resource.updateReport(identifier, 'Data', 'data_hash:'+response.header.data_hash); 
                
        //Object.keys(response_payloads).forEach(function(key) {resource.updateLog(key+':'+param[key]);});
        resource.updateStatus(identifier, result);            
      });            
      break;
      
     case 'ValidateInstalledChaincodes':
      query.getInstalledChaincodes(peer, 'installed', username, orgname).then(function (chaincodes) {
      var result=false;
       chaincodes.forEach(function(chaincode){
         if(chaincode.toString()=='name: '+chainName+', version: '+chainVersion+', path: '+chainPath){
            resource.updateReport(identifier, 'Data', chaincode); 
            result=true;
         }
       });
       resource.updateStatus(identifier, result); 
      });
      break;

     case 'ValidateChainLength':                        
      query.getChainInfo(peer, username, orgname).then((blockchainInfo) => {
		if (blockchainInfo) {
                        var blockShift = Number.parseInt(blockchainInfo.height) - Number.parseInt(oldChainLenght);
                        resource.updateReport(identifier, 'Data', "Blocks:"+blockchainInfo.height);  
                        if(blockShift>0){
                                resource.updateLog('Current block chain lenght:'+blockchainInfo.height + ', shifted by '+ blockShift);
                                resource.updateReport(identifier, 'Status', 'Pass');     
                        }else{
                                resource.updateReport(identifier, 'Status', 'Fail');     
                        }
		}});
      break;
      
     case 'ValidateBlockHash':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var offset = resource.fetchColumnData(testData[i],'HashOffset');
      query.getChainInfo(peer, username, orgname).then((blockchainInfo) => {
		if (blockchainInfo) {
			resource.updateLog("currentBlockHash:"+blockchainInfo.currentBlockHash);
                        resource.updateLog("previousBlockHash:"+blockchainInfo.previousBlockHash);
                        if (blockchainInfo.currentBlockHash.offset == offset){
                                resource.updateLog('Current block offset:'+blockchainInfo.currentBlockHash.offset + ', validation: OK');
                                resource.updateReport(identifier, 'Status', 'Pass');   
                        }    else{
                                resource.updateReport(identifier, 'Status', 'Fail');   
                        }              
                        resource.updateReport(identifier, 'Data', blockchainInfo.currentBlockHash);    
		}});
      break;
     case 'ValidateChaincodeInvoke':
        invoke.invokeChaincode(peers, channel, chainName, chainFunction, params, username, orgname).then(function(trxnId) {     
      
        query.queryChaincode(peers[0], channel, chainName, params[0], 'query', username, orgname);
        query.queryChaincode(peers[1], channel, chainName, params[1], 'query', username, orgname);
	resource.updateLog('TransactionID:'+trxnId);	

        query.getTransactionByID(peers[0], trxnId, username, orgname).then((payloads) => {
        //npm install --save get-type-of@latest
            resource.updateReport(identifier, 'Data', 'TransactionID:'+trxnId);  
            if(trxnId==null || trxnId==''){
               resource.updateReport(identifier, 'Status', 'Fail'); 
            }else{
               resource.updateReport(identifier, 'Status', 'Pass'); 
            }
            Object.keys(payloads).forEach(function(key) {
               resource.updateLog(key+':'+payloads[key]);	                       
            });
	});;        
      });
      sleep(5000);
      break;
      
     case 'ValidateUserEnrollment':      
      helper.getRegisteredUsers(username, orgname, true).then(function(response) {
         expectedMessage = username + ' ' + expectedMessage;
         if(response.message===expectedMessage){
            resource.updateReport(identifier, 'Status', 'Pass'); 
         }else{
            resource.updateReport(identifier, 'Status', 'Fail'); 
         }
         resource.updateReport(identifier, 'Data', 'Secret:'+response.secret);
         Object.keys(response).forEach(function(key) {resource.updateLog(key+':'+response[key]);});
         
         });                             
      break;      
      
     case 'ValidateTransactionSignature':
      query.getBlockByNumber(peer, blockNumber, username, orgname).then(function (response) {
        var result=false;
        var signature = response.data.data[0].payload.header.signature_header.creator.IdBytes;
        if(signature.indexOf(expectedMessage)>=0)result=true;
        resource.updateLog('signature:'+response.data.data[0].payload.header.signature_header.creator.IdBytes);
        
        resource.updateStatus(identifier, result);  
        resource.updateReport(identifier, 'Data', signature);          
      });            
      break;      
      
     case 'ValidateNewtorkInformation':
        var result=false;
        var peerCount = 0, ordererCount =0, ordererInfo;
        var peers = resource.fetchColumnData(testData[i],'Peer');
        var ordereres = resource.fetchColumnData(testData[i],'Organization');     
        for (var channel in helper.getChannels())
        {
            resource.updateLog('Channels:'+channel);
            var org=helper.getChannelForOrg(channel);
            resource.updateLog('Channel-'+channel+':'+org);
            resource.updateLog('Peer-'+channel+':'+org.getOrderers());
            resource.updateLog('Orderer-'+channel+':'+org.getPeers());    
            peerCount=parseInt(peerCount+org.getPeers().length);   
            ordererCount=parseInt(ordererCount+org.getOrderers().length);   
            ordererInfo=ordererInfo+ org.getPeers();       
        }
        resource.updateLog('Peer count-'+peerCount);
        resource.updateLog('Orderer count-'+ordererCount);
        if(parseInt(peers)==peerCount && parseInt(ordereres)==ordererCount)result=true;
        resource.updateStatus(identifier, result);  
        resource.updateReport(identifier, 'Data', "Orderrers:"+ordererInfo);          
      break;       
    }    
    sleep(2000);
  }
}


/*
query.getBlockByNumber(peer, '1', username, orgname);
query.getInstalledChaincodes(peer, 'installed', username, orgname);
*/

