'use strict';
var resource= require('./resource-handler');

require('./config.js');
const delay = require('delay');
var hfc = require('fabric-client');
var helper = require('./app/helper.js');
var channels = require('./app/create-channel.js');
var join = require('./app/join-channel.js');
var install = require('./app/install-chaincode.js');
var instantiate = require('./app/instantiate-chaincode.js');
var invoke = require('./app/invoke-transaction.js');
var query = require('./app/query.js');
var sleep = require('system-sleep');

////////////////////////////////////////////////////////////////////////////////////

resource.resetReport();
var testData = resource.loadExecutionManager('./ExecutionManager.xlsx', 'Execution');

//console.log(helper.getRegisteredUsers(username, orgname, true));

for(var i=0;i<testData.length;i++){
  if(resource.fetchColumnData(testData[i],'Enabled')=='Yes'){
    var scenario = resource.fetchColumnData(testData[i],'Function');
    console.log('Executing scenario '+scenario+"...");sleep(2000);
    switch(scenario){
     case 'ValidateChannelInfo':
      var identifier = "101";
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var channel = resource.fetchColumnData(testData[i],'Channel');

      query.getChannels(peer, username, orgname).then(function(response) {
	var channels = [];
        var result=false;
	for (let i = 0; i < response.channels.length; i++) {
           if(response.channels[i].channel_id==channel){
              resource.updateReport(identifier, 'Data', response.channels[i].channel_id);  
              result=true;
              break;
           }
	}
        resource.updateStatus(identifier, result);            
      });
      break;

     case 'ValidateInstalledChaincodes':
      var identifier = "103";
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var code = resource.fetchColumnData(testData[i],'Chaincode');
      var version = resource.fetchColumnData(testData[i],'ChainVersion');
      var path = resource.fetchColumnData(testData[i],'ChainPath');
      query.getInstalledChaincodes(peer, 'installed', username, orgname).then(function (chaincodes) {
      var result=false;
       chaincodes.forEach(function(chaincode){
         if(chaincode.toString()=='name: '+code+', version: '+version+', path: '+path){
            resource.updateReport(identifier, 'Data', chaincode); 
            result=true;
         }
       });
       resource.updateStatus(identifier, result); 
      });
      break;

     case 'ValidateChainLength':
      var identifier = "104";
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var oldChainLenght = resource.fetchColumnData(testData[i],'ChainLength');
                        
      query.getChainInfo(peer, username, orgname).then((blockchainInfo) => {
		if (blockchainInfo) {
                        var blockShift = Number.parseInt(blockchainInfo.height) - Number.parseInt(oldChainLenght);
                        resource.updateReport(identifier, 'Data', "Blocks:"+blockchainInfo.height);  
                        if(blockShift>0){
                                console.log('Current block chain lenght:'+blockchainInfo.height + ', shifted by '+ blockShift);
                                resource.updateReport(identifier, 'Status', 'Pass');     
                        }else{
                                resource.updateReport(identifier, 'Status', 'Fail');     
                        }
		}});
      break;
     case 'ValidateBlockHash':
      var identifier = "105";
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var offset = resource.fetchColumnData(testData[i],'HashOffset');
      query.getChainInfo(peer, username, orgname).then((blockchainInfo) => {
		if (blockchainInfo) {
			console.log("currentBlockHash:"+blockchainInfo.currentBlockHash);
                        console.log("previousBlockHash:"+blockchainInfo.previousBlockHash);
                        if (blockchainInfo.currentBlockHash.offset == offset){
                                console.log('Current block offset:'+blockchainInfo.currentBlockHash.offset + ', validation: OK');
                                resource.updateReport(identifier, 'Status', 'Pass');   
                        }    else{
                                resource.updateReport(identifier, 'Status', 'Pass');   
                        }              
                        resource.updateReport(identifier, 'Data', blockchainInfo.currentBlockHash);    
		}});
      break;
     case 'InvokeChaincode':
      var identifier = "106";
      var peers = resource.fetchColumnData(testData[i],'Peer').split(', ');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var channelName = resource.fetchColumnData(testData[i],'Channel');
      var chaincodeName = resource.fetchColumnData(testData[i],'Chaincode');

      invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peers[0], channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peers[1], channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID(peers[0], trxnId, username, orgname);
        query.getTransactionByID(peers[1], trxnId, username, orgname).then((block) => {
                        console.log(block);
			console.log("block:"+blockc.header);
		});;

        query.getBlockByNumber(peer, blockId, username, orgname);        
      });
      break;
    }
    sleep(2000);
  }
}


/*
query.getChannels(peer, username, orgname);
query.getBlockByNumber(peer, '1', username, orgname);
query.getInstalledChaincodes(peer, 'installed', username, orgname);
query.getChainInfo(peer, username, orgname)

invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peer, channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peer, channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID('peer1', trxnId, 'Avijit', 'org1');
        query.getTransactionByID('peer2', trxnId, 'Barry', 'org1');

        query.getBlockByNumber(peer, blockId, username, orgname);        
});

*/

