'use strict';
var resource= require('./resource-handler');
var log4js = require('log4js');
var logger = log4js.getLogger('SampleWebApp');
var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var util = require('util');
var app = express();
var expressJWT = require('express-jwt');
var jwt = require('jsonwebtoken');
var bearerToken = require('express-bearer-token');
var cors = require('cors');

require('./config.js');
var hfc = require('fabric-client');

var helper = require('./app/helper.js');
var channels = require('./app/create-channel.js');
var join = require('./app/join-channel.js');
var install = require('./app/install-chaincode.js');
var instantiate = require('./app/instantiate-chaincode.js');
var invoke = require('./app/invoke-transaction.js');
var query = require('./app/query.js');
var host = process.env.HOST || hfc.getConfigSetting('host');
var port = process.env.PORT || hfc.getConfigSetting('port');

////////////////////////////////////////////////////////////////////////////////////

var testData = resource.loadExecutionManager('./ExecutionManager.xlsx');
//console.log(testData[2]);




var peers=['peer1','peer2']
var peer=peers[0];
var username='Avijit';
var orgname='org1';
var channelName='mychannel';
var chaincodeName='mycc';
var chaincodeVersion='v0';

//console.log(helper.getRegisteredUsers(username, orgname, true));

for (var channel in helper.getChannels()){
    console.log('Channels:'+channel);
}

for (var client in helper.getClients()){
    console.log('Clients:'+client);
}

for(var i=0;i<testData.length;i++){
  if(resource.fetchColumnData(testData[i],'Enabled')=='Yes'){
    switch(resource.fetchColumnData(testData[i],'Function')){
     case 'GetChannels':
      query.getChannels(peer, username, orgname);
      break;
     case 'GetInstalledChaincodes':
      query.getInstalledChaincodes(peer, 'installed', username, orgname);
      break;
     case 'getChainInfo':
      query.getChainInfo(peer, username, orgname)
      break;
     case 'InvokeChaincode':
      invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peer, channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peer, channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID('peer1', trxnId, 'Avijit', 'org1');
        query.getTransactionByID('peer2', trxnId, 'Barry', 'org1');

        query.getBlockByNumber(peer, blockId, username, orgname);        
      });
      break;
    }
  }
}

/*
query.getChannels(peer, username, orgname);
query.getBlockByNumber(peer, '1', username, orgname);
query.getInstalledChaincodes(peer, 'installed', username, orgname);
query.getChainInfo(peer, username, orgname)

invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peer, channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peer, channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID('peer1', trxnId, 'Avijit', 'org1');
        query.getTransactionByID('peer2', trxnId, 'Barry', 'org1');

        query.getBlockByNumber(peer, blockId, username, orgname);        
});

*/

