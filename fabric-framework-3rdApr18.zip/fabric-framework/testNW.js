'use strict';
var log4js = require('log4js');
var logger = log4js.getLogger('SampleWebApp');
var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var util = require('util');
var app = express();
var expressJWT = require('express-jwt');
var jwt = require('jsonwebtoken');
var bearerToken = require('express-bearer-token');
var cors = require('cors');

require('./config.js');
var hfc = require('fabric-client');

var helper = require('./app/helper.js');
var channels = require('./app/create-channel.js');
var join = require('./app/join-channel.js');
var install = require('./app/install-chaincode.js');
var instantiate = require('./app/instantiate-chaincode.js');
var invoke = require('./app/invoke-transaction.js');
var query = require('./app/query.js');
var host = process.env.HOST || hfc.getConfigSetting('host');
var port = process.env.PORT || hfc.getConfigSetting('port');

var Sync = require('sync');

//////////////////////////////////////////////////////////////////////////////////////////////

var peer='peer1';
var blockId='1';
var username='Avijit';
var orgname='org1';
var trxnId='7dc6885d01113897bff5e6fab5c74fe106b90101855fe6b6b31037545f7400d9';
var channelName='mychannel';
var chaincodeName='mycc';
var chaincodeVersion='v0';
var peers=['peer1','peer2']

for (var channel in helper.getChannels())
{
    console.log('Channels:'+channel);
}

for (var client in helper.getClients())
{
    console.log('Clients:'+client);
}

var channel1=helper.getChannelForOrg('org1');
console.log('Channel-org1:'+channel1);
console.log('Peer-org1:'+channel1.getOrderers());
console.log('Orderer-org1:'+channel1.getPeers());

var channel2=helper.getChannelForOrg('org2');
console.log('Channel-org2:'+channel2);
console.log('Peer-org2:'+channel2.getOrderers());
console.log('Peer-org2:'+channel2.getPeers());

//console.log('Msps:'+helper.getMspID());

helper.getRegisteredUsers(username, orgname, true);

query.getChannels(peer, username, orgname);
query.getBlockByNumber(peer, blockId, username, orgname);
query.getTransactionByID(peer, trxnId, username, orgname);
query.getInstalledChaincodes(peer, 'installed', username, orgname);
query.getChainInfo(peer, username, orgname)

invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['B','A','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peer, channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peer, channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID('peer1', trxnId, 'Avijit', 'org1');
        query.getTransactionByID('peer2', trxnId, 'Barry', 'org1');

        query.getBlockByNumber(peer, blockId, username, orgname);        
});

