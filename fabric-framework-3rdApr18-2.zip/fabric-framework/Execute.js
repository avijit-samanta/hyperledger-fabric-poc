'use strict';
var resource= require('./resource-handler');

require('./config.js');
var hfc = require('fabric-client');
var helper = require('./app/helper.js');
var channels = require('./app/create-channel.js');
var join = require('./app/join-channel.js');
var install = require('./app/install-chaincode.js');
var instantiate = require('./app/instantiate-chaincode.js');
var invoke = require('./app/invoke-transaction.js');
var query = require('./app/query.js');

////////////////////////////////////////////////////////////////////////////////////

var testData = resource.loadExecutionManager('./ExecutionManager.xlsx');

//console.log(helper.getRegisteredUsers(username, orgname, true));

for(var i=0;i<testData.length;i++){
  if(resource.fetchColumnData(testData[i],'Enabled')=='Yes'){
    // ValidateChannelInfo
    switch(resource.fetchColumnData(testData[i],'Function')){
     case 'ValidateChannelInfo':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var channel = resource.fetchColumnData(testData[i],'Channel');

      query.getChannels(peer, username, orgname).then(function(response) {
	var channels = [];
        var result=false;
	for (let i = 0; i < response.channels.length; i++) {
           if(response.channels[i].channel_id==channel){
              result=true;
              break;
           }
	}
	console.log('ValidateChannelInfo:'+result);        
      });
      break;

     case 'GetInstalledChaincodes':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      query.getInstalledChaincodes(peer, 'installed', username, orgname);
      break;
     case 'getChainInfo':
      var peer = resource.fetchColumnData(testData[i],'Peer');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      query.getChainInfo(peer, username, orgname)
      break;
     case 'InvokeChaincode':
      var peers = resource.fetchColumnData(testData[i],'Peer').split(', ');
      var username = resource.fetchColumnData(testData[i],'User');
      var orgname = resource.fetchColumnData(testData[i],'Organization');
      var channelName = resource.fetchColumnData(testData[i],'Channel');
      var chaincodeName = resource.fetchColumnData(testData[i],'Chaincode');

      invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peers[0], channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peers[1], channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID(peers[0], trxnId, username, orgname);
        query.getTransactionByID(peers[1], trxnId, username, orgname);

        query.getBlockByNumber(peer, blockId, username, orgname);        
      });
      break;
    }
  }
}

/*
query.getChannels(peer, username, orgname);
query.getBlockByNumber(peer, '1', username, orgname);
query.getInstalledChaincodes(peer, 'installed', username, orgname);
query.getChainInfo(peer, username, orgname)

invoke.invokeChaincode(peers, channelName, chaincodeName, 'move', ['A','B','25'], username, orgname).then(function(trxnId) {
        query.queryChaincode(peer, channelName, chaincodeName, 'A', 'query', username, orgname);
        query.queryChaincode(peer, channelName, chaincodeName, 'B', 'query', username, orgname);
	console.log('TransactionID:'+trxnId);

        query.getTransactionByID('peer1', trxnId, 'Avijit', 'org1');
        query.getTransactionByID('peer2', trxnId, 'Barry', 'org1');

        query.getBlockByNumber(peer, blockId, username, orgname);        
});

*/

